#ifndef _SortareSiruri_
#define _SortareSiruri_
#pragma warning(disable : 4996)

char **citireVSiruri(int n);
void sortareVSiruri(char ** vsiruri, int n);
void afisareVSiruri(char **vsiruri, int n);
void dealocareVSiruri(char **vsiruri, int n);

#endif

