#include<iostream>
#include<conio.h>
#include"SortareSiruri.h"
using namespace std;

int main() {
	int n;
	char** vsiruri;
	
	cout << "n=";
	cin >> n;
	vsiruri = citireVSiruri(n);
	sortareVSiruri(vsiruri, n);
	afisareVSiruri(vsiruri, n);
	dealocareVSiruri(vsiruri, n);
	_getch();
	return 0;
}
