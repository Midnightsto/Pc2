#include<iostream>
#include<string.h>
#include"SortareSiruri.h"
using namespace std;

char **citireVSiruri(int n) {
	char buffer[100];
	char **vsiruri = new char*[n];
	cin.ignore(100, '\n');
	for(int i=0; i<n; i++) {
		int len;
		cin.getline(buffer, 100);
		len = strlen(buffer);
		vsiruri[i] = new char[len + 1];
		strcpy(vsiruri[i], buffer); 
	}
	return vsiruri;
}

void sortareVSiruri(char ** vsiruri, int n) {
	int suntPerm = 1;
	while(suntPerm) {
		suntPerm = 0;
		for(int i=0; i<n-1; i++) {
		    if(strcmp(vsiruri[i],
                        vsiruri[i+1]) > 0) {
				char *aux = vsiruri[i];
				vsiruri[i] = vsiruri[i+1];
				vsiruri[i+1] = aux;
				suntPerm = 1;
			}
		}
	}
}

void afisareVSiruri(char **vsiruri, int n) {
	cout << "Sirurile sortate sunt:" << endl;
	for(int i=0; i<n; i++) {
		cout << vsiruri[i] << endl;
	}
}

void dealocareVSiruri(char **vsiruri, int n) {
	for(int i=0; i<n; i++) {
		delete[] vsiruri[i];
	}
	delete[] vsiruri;
}
